package es.um.redes.nanoFiles.tcp.message;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

import es.um.redes.nanoFiles.util.FileInfo;

public class PeerMessage {

	public static final byte HASH_LENGHT = 40;
	private boolean ENCRYPT = false;

	private byte opcode;

	/*
	 * TODO: (Boletín MensajesBinarios) Añadir atributos u otros constructores
	 * específicos para crear mensajes con otros campos, según sea necesario
	 * 
	 */
	//download
	private byte longFileName;
	private String fileName;
	//metadata
	private int fileSize;
	private String fileHash; //tmb para chunkRequest
	//chunkRequest
	private int chunkInicio;
	private int chunkFin;
	//chunkResponse
	private int posicionChunk;
	private byte[] chunk;
    // Constructor por defecto: encriptación activada
    public PeerMessage() {
        opcode = PeerMessageOps.OPCODE_INVALID_CODE;
        ENCRYPT = true; // Encriptar por defecto
    }

    // Constructor con opcode
    public PeerMessage(byte op) {
        opcode = op;
        ENCRYPT = true;
    }

    // Constructor con opcode y opción de encriptación
    public PeerMessage(byte op, boolean encrypt) {
        opcode = op;
        this.ENCRYPT = encrypt;
    }

    // Constructores existentes, añadiendo parámetro encrypt
    public PeerMessage(byte op, byte longName, String name, boolean encrypt) {
        this(op, encrypt);
        longFileName = longName;
        fileName = new String(name);
    }

    public PeerMessage(byte op, int size, String hash, boolean encrypt) {
        this(op, encrypt);
        fileSize = size;
        fileHash = new String(hash);
    }

    public PeerMessage(byte op, String hash, int chunkInicial, int chunkFinal, boolean encrypt) {
        this(op, encrypt);
        fileHash = hash;
        chunkInicio = chunkInicial;
        chunkFin = chunkFinal;
    }

    public PeerMessage(byte op, int posicionChunk, byte[] chunk, boolean encrypt) {
        this(op, encrypt);
        this.posicionChunk = posicionChunk;
        this.chunk = chunk;
    }

    // Getter y Setter para encrypt
    public boolean isEncrypt() {
        return ENCRYPT;
    }

    public void setEncrypt(boolean encrypt) {
        this.ENCRYPT = encrypt;
    }
	/*
	 * TODO: (Boletín MensajesBinarios) Crear métodos getter y setter para obtener
	 * los valores de los atributos de un mensaje. Se aconseja incluir código que
	 * compruebe que no se modifica/obtiene el valor de un campo (atributo) que no
	 * esté definido para el tipo de mensaje dado por "operation".
	 */
	public byte getOpcode() {
		return opcode;
	}
	
	public int getLongFileName() {
		return longFileName;
	}
	
	public String getFileName() {
		return fileName;
	}
	
	public int getFileSize() {
		return fileSize;
	}
	
	public String getFileHash() {
		return fileHash;
	}
	
	public int getChunkInicio() {
		return chunkInicio;
	}
	
	public int getChunkFin() {
		return chunkFin;
	}
	
	public byte[] getChunk() {
		return chunk;
	}
	
	public int getPosicionChunk() {
		return posicionChunk;
	}
	public void setLongFileName(byte longitud) {
		if(PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_DOWNLOAD_FILE))|| PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_UPLOAD_REQUEST))) {
			longFileName = longitud;
		}else {
			throw new RuntimeException(
					"PeerMessage: setLongFileName called for message of unexpected type (" + PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}

	public void setFileName(String name) {
		if(PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_DOWNLOAD_FILE))|| PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_UPLOAD_REQUEST))) {
			fileName = name;
		}else {
			throw new RuntimeException(
					"PeerMessage: setFileName called for message of unexpected type (" + PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}
	
	public void setFileHash(String hash) {
		if(PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_FILE_METADATA)) || PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_CHUNK_REQUEST))|| PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_UPLOAD_REQUEST))) {
			fileHash = hash;
		}else {
			throw new RuntimeException(
					"PeerMessage: setFileHash called for message of unexpected type (" + PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}
	
	public void setFileSize(int size) {
		if(PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_FILE_METADATA)) || PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_UPLOAD_REQUEST))) {
			fileSize = size;
		}else {
			throw new RuntimeException(
					"PeerMessage: setFileSize called for message of unexpected type (" + PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}
	
	public void setChunkInicio(int chunkInicial) {
		if(PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_CHUNK_REQUEST))) {
			chunkInicio = chunkInicial;
		}else {
			throw new RuntimeException(
					"PeerMessage: setChunkInicio called for message of unexpected type (" + PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}
	
	public void setChunkFin(int chunkFinal) {
		if(PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_CHUNK_REQUEST))) {
			chunkFin = chunkFinal;
		}else {
			throw new RuntimeException(
					"PeerMessage: setChunkFin called for message of unexpected type (" + PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}
	
	public void setChunk(byte[] chunk) {
		if(PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_CHUNK_RESPONSE)) || PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_UPLOAD_DATA))) {
			this.chunk = chunk;
		}else {
			throw new RuntimeException(
					"PeerMessage: setChunk called for message of unexpected type (" + PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}
	
	public void setPosicionChunk(int posicionChunk) {
		if(PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_CHUNK_RESPONSE)) || PeerMessageOps.opcodeToOperation(opcode).equals(PeerMessageOps.opcodeToOperation(PeerMessageOps.OPCODE_UPLOAD_DATA))) {
			this.posicionChunk = posicionChunk;
		}else {
			throw new RuntimeException(
					"PeerMessage: setPosicionChunk called for message of unexpected type (" + PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}
	/**
	 * Método de clase para parsear los campos de un mensaje y construir el objeto
	 * PeerMessage que contiene los datos del mensaje recibido
	 * 
	 * @param data El array de bytes recibido
	 * @return Un objeto de esta clase cuyos atributos contienen los datos del
	 *         mensaje recibido.
	 * @throws IOException
	 */
	public static PeerMessage readMessageFromInputStream(DataInputStream dis) throws IOException {
		/*
		 * TODO: (Boletín MensajesBinarios) En función del tipo de mensaje, leer del
		 * socket a través del "dis" el resto de campos para ir extrayendo con los
		 * valores y establecer los atributos del un objeto PeerMessage que contendrá
		 * toda la información del mensaje, y que será devuelto como resultado. NOTA:
		 * Usar dis.readFully para leer un array de bytes, dis.readInt para leer un
		 * entero, etc.
		 */
		byte opcode = dis.readByte();
		PeerMessage message = new PeerMessage(opcode);
		switch (opcode) {
		case PeerMessageOps.OPCODE_DOWNLOAD_FILE:
			byte longitudNombre = dis.readByte();
			byte[] nombre = new byte[longitudNombre];
			dis.readFully(nombre);
			String nombreCadena = new String(nombre);
			message.setLongFileName(longitudNombre);
			message.setFileName(nombreCadena);
			break;
		case PeerMessageOps.OPCODE_FILE_METADATA:
			int tamanio = dis.readInt();
			byte[] hash = new byte[PeerMessageOps.TAMANIO_HASH];
			dis.readFully(hash);
			String hashCadena = new String(hash);
			message.setFileSize(tamanio);
			message.setFileHash(hashCadena);
			break;
		case PeerMessageOps.OPCODE_CHUNK_REQUEST: {
			byte[] hashh = new byte[PeerMessageOps.TAMANIO_HASH];
			dis.readFully(hashh);
			String hashChain = new String(hashh);
			int inicio = dis.readInt();
			int fin = dis.readInt();
			message.setFileHash(hashChain);
			message.setChunkInicio(inicio);
			message.setChunkFin(fin);
			break;
		}
		case PeerMessageOps.OPCODE_CHUNK_RESPONSE: {
			int inicio = dis.readInt();
			int longitud = dis.readInt();
			byte[] datos = new byte[longitud];
			dis.readFully(datos);
			message.setPosicionChunk(inicio);
			message.setChunk(datos);
			break;
		}
		case PeerMessageOps.OPCODE_INVALID_CODE:
		case PeerMessageOps.OPCODE_END_OF_FILE:
			break;
		case PeerMessageOps.OPCODE_UPLOAD_REQUEST:
		    int size = dis.readInt();
		    byte[] hashBytes = new byte[PeerMessageOps.TAMANIO_HASH];
		    dis.readFully(hashBytes);
		    String hashStr = new String(hashBytes);
		    byte longName = dis.readByte();
		    byte[] nameBytes = new byte[longName];
		    dis.readFully(nameBytes);
		    String nameStr = new String(nameBytes);
		    message.setFileSize(size);
		    message.setFileHash(hashStr);
		    message.setLongFileName(longName);
		    message.setFileName(nameStr);
		    break;
		case PeerMessageOps.OPCODE_UPLOAD_DATA:
		    int start = dis.readInt();
		    int length = dis.readInt();
		    byte[] chunkData = new byte[length];
		    dis.readFully(chunkData);
		    message.setPosicionChunk(start);
		    message.setChunk(chunkData);
		    break;
		case PeerMessageOps.OPCODE_UPLOAD_COMPLETE:
		case PeerMessageOps.OPCODE_UPLOAD_ACCEPTED:
		case PeerMessageOps.OPCODE_UPLOAD_REJECTED:
		    // No datos extra
		    break;

		default:
			System.err.println("PeerMessage.readMessageFromInputStream doesn't know how to parse this message opcode: "
					+ PeerMessageOps.opcodeToOperation(opcode));
			System.exit(-1);
		}
		return message;
	}

	public void writeMessageToOutputStream(DataOutputStream dos) throws IOException {
		/*
		 * TODO (Boletín MensajesBinarios): Escribir los bytes en los que se codifica el
		 * mensaje en el socket a través del "dos", teniendo en cuenta opcode del
		 * mensaje del que se trata y los campos relevantes en cada caso. NOTA: Usar
		 * dos.write para leer un array de bytes, dos.writeInt para escribir un entero,
		 * etc.
		 */

		dos.writeByte(opcode);
		switch (opcode) {
		case PeerMessageOps.OPCODE_AMBIGUOUS: 
		case PeerMessageOps.OPCODE_INVALID_CODE:
		case PeerMessageOps.OPCODE_FILE_NOT_FOUND:{
			break;
		}
		case PeerMessageOps.OPCODE_DOWNLOAD_FILE: 
		    byte[] nameBytes = fileName.getBytes();
		    dos.writeByte(longFileName); // Escribir longitud como byte
		    dos.write(nameBytes); // Escribir bytes del nombre
		    break;
		case PeerMessageOps.OPCODE_FILE_METADATA:
			dos.writeInt(fileSize);
			dos.write(fileHash.getBytes());
			break;
		case PeerMessageOps.OPCODE_CHUNK_REQUEST: {
			dos.write(fileHash.getBytes());
			dos.writeInt(chunkInicio);
			dos.writeInt(chunkFin);
			break;
		}
		case PeerMessageOps.OPCODE_CHUNK_RESPONSE: {
			dos.writeInt(chunkInicio);
			dos.writeInt(chunk.length);
			dos.write(chunk);
			break;
		}
		case PeerMessageOps.OPCODE_UPLOAD_REQUEST:
		    dos.writeInt(fileSize);
		    dos.write(fileHash.getBytes());
		    dos.writeByte(longFileName);
		    dos.write(fileName.getBytes());
		    break;
		case PeerMessageOps.OPCODE_UPLOAD_DATA:
		    dos.writeInt(posicionChunk); // inicio
		    dos.writeInt(chunk.length);  // longitud del fragmento
		    dos.write(chunk);            // contenido
		    break;
		case PeerMessageOps.OPCODE_UPLOAD_COMPLETE:
		    break; // No lleva datos
		case PeerMessageOps.OPCODE_UPLOAD_ACCEPTED:
		case PeerMessageOps.OPCODE_UPLOAD_REJECTED:
		    break; // No llevan datos tampoco
		default:
			System.err.println("PeerMessage.writeMessageToOutputStream found unexpected message opcode " + opcode + "("
					+ PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}
}

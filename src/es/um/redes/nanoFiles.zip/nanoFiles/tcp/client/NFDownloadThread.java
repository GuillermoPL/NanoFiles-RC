package es.um.redes.nanoFiles.tcp.client;

import java.io.IOException;
import java.net.InetSocketAddress;

import es.um.redes.nanoFiles.tcp.message.PeerMessage;
import es.um.redes.nanoFiles.tcp.message.PeerMessageOps;

public class NFDownloadThread extends Thread {
    public static final boolean DOWNLOAD_DEBUG_MODE = true;
    private static final int MAX_RETRIES = 3; // Número máximo de reintentos
    private static final int RETRY_DELAY_MS = 500; // Espera entre reintentos

    private final InetSocketAddress[] serverAddresses;
    private final String fileHash;
    private final int chunkIndex;
    private final int inicio;
    private final int fin;
    private final byte[] sharedBuffer;
    private final boolean[] chunkSuccess;
    private final Object lock;

    public NFDownloadThread(InetSocketAddress[] serverAddresses, String fileHash, int chunkIndex,
                             int inicio, int fin, byte[] sharedBuffer, boolean[] chunkSuccess, Object lock) {
        this.serverAddresses = serverAddresses;
        this.fileHash = fileHash;
        this.chunkIndex = chunkIndex;
        this.inicio = inicio;
        this.fin = fin;
        this.sharedBuffer = sharedBuffer;
        this.chunkSuccess = chunkSuccess;
        this.lock = lock;
    }

    @Override
    public void run() {
        int attempt = 0;
        boolean chunkDownloaded = false;

        while (attempt < MAX_RETRIES && !chunkDownloaded) {
            attempt++;

            for (InetSocketAddress serverAddress : serverAddresses) {
                try (NFConnector connector = new NFConnector(serverAddress)) {
                    if (DOWNLOAD_DEBUG_MODE) {
                        System.out.println("[Attempt " + attempt + "] Thread " + chunkIndex + 
                            ": Sending CHUNK_REQUEST to " + serverAddress);
                    }

                    PeerMessage chunkRequest = new PeerMessage(PeerMessageOps.OPCODE_CHUNK_REQUEST, fileHash, inicio, fin, false);
                    chunkRequest.writeMessageToOutputStream(connector.getDos());

                    PeerMessage respuestaChunk = PeerMessage.readMessageFromInputStream(connector.getDis());

                    if (respuestaChunk.getOpcode() == PeerMessageOps.OPCODE_CHUNK_RESPONSE) {
                        byte[] datos = respuestaChunk.getChunk();
                        synchronized (lock) {
                            System.arraycopy(datos, 0, sharedBuffer, inicio, datos.length);
                            chunkSuccess[chunkIndex] = true;
                        }
                        if (DOWNLOAD_DEBUG_MODE) {
                            System.out.println("[SUCCESS] Thread " + chunkIndex + ": Chunk [" + inicio + "-" + fin + 
                                "] downloaded from " + serverAddress);
                        }
                        chunkDownloaded = true;
                        break; // Salimos del for
                    } else {
                        System.err.println("[ERROR] Thread " + chunkIndex + ": Unexpected response " + 
                            PeerMessageOps.opcodeToOperation(respuestaChunk.getOpcode()));
                    }

                } catch (IOException e) {
                    System.err.println("[ERROR] Thread " + chunkIndex + ": Connection failed to " + 
                        serverAddress + " - " + e.getMessage());
                    // Probará otro servidor
                }
            }

            if (!chunkDownloaded) {
                if (attempt < MAX_RETRIES) {
                    if (DOWNLOAD_DEBUG_MODE) {
                        System.out.println("[Retrying] Thread " + chunkIndex + ": waiting " + RETRY_DELAY_MS + " ms before retry...");
                    }
                    try {
                        Thread.sleep(RETRY_DELAY_MS);
                    } catch (InterruptedException e) {
                        // Ignorar
                    }
                }
            }
        }

        if (!chunkDownloaded) {
            System.err.println("[FAILED] Thread " + chunkIndex + ": Failed to download chunk [" + inicio + "-" + fin + 
                               "] after " + MAX_RETRIES + " attempts.");
        }
    }
}
